/**
 * Provides Spring Integration components for doing outbound operations. 
 */
package sipackage.outbound;