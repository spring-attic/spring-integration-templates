/**
 * Provides core classes of the SIAdapterUpperPrefix module.
 */
package sipackage.core;