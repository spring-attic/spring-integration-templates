Spring Integration - War Template
================================================================================

This template is meant for running Spring Integration inside of an Servlet
Container. This template by default uses Twitter Integration to show some basic
functionality.

Please keep in mind, that the provided Web UI is not necessary. You can in fact
run Spring Integration processes without any MVC integration. Thus, you can
run your Spring Integration components as mere backend processes.

--------------------------------------------------------------------------------

For help please take a look at the Spring Integration documentation:

http://www.springsource.org/spring-integration

