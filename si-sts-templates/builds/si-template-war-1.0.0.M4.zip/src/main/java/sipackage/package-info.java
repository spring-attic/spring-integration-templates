/**
 * Root package of the SI-TEMPLATE-ARTIFACT-ID application.
 */
package sipackage;