/**
 * Provides Spring Integration components for doing outbound operations. 
 */
package stsorg.stsspring.stsint.outbound;