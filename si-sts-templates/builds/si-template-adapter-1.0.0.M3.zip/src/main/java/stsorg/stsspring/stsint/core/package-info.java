/**
 * Provides core classes of the SIAdapterUpperPrefix module.
 */
package stsorg.stsspring.stsint.core;