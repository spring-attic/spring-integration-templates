/**
 * Root package of the SIAdapterUpperPrefix Module.
 */
package stsorg.stsspring.stsint;