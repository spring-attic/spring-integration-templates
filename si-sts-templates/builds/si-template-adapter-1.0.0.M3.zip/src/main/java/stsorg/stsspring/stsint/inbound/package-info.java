/**
 * Provides inbound Spring Integration SIAdapterUpperPrefix components.
 */
package stsorg.stsspring.stsint.inbound;