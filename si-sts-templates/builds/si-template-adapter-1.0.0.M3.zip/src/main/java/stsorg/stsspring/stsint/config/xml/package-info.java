/**
 * Provides parser classes to provide Xml namespace support for the SIAdapterUpperPrefix components.
 */
package stsorg.stsspring.stsint.config.xml;