/**
 * Provides various support classes used across Spring Integration SIAdapterUpperPrefix Components.
 */
package stsorg.stsspring.stsint.support;
